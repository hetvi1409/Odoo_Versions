# -*- coding: utf-8 -*-
{
    'name': "Attachment Preview",
    'summary': """
        Attachment Preview / Preview Attachment / Preview Excel / Preview Word / Preview Video / Preview PDF / Preview Image
    """,
    'description': """
        attachment preview(PDF、Excel、Word、Video、Image)
    """,
    'author': "x2soft",
    'website': "www.odoo-dl.com",
    'price': 50,
    'category': 'Website',
    'currency': "USD",
    'support': "yuze@odoo-dl.com",
    'category': 'Website',
    'version': '0.1',
    'license': 'OPL-1',
    'depends': ['base', 'mail'],
    'images': [
        'static/description/main_screenshot.gif'
    ],
    'assets': {
        'web.assets_backend': [
            'x2_attachment_preview/static/lib/office/docx/docx.js',
            'x2_attachment_preview/static/lib/office/docx/index.css',
            'x2_attachment_preview/static/lib/office/excel/excel.js',
            'x2_attachment_preview/static/lib/office/excel/index.css',
            'x2_attachment_preview/static/src/many2many_binary.js',
            'x2_attachment_preview/static/src/many2many_binary.xml'
        ],
    },
    'installable': True
}

